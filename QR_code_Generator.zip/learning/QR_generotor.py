import qrcode
from PIL import Image


data = input("Enter the URL:  ")

qr = qrcode.QRCode(
    version = 1,
    box_size = 10,
    border = 4
)

qr.add_data(data)
qr.make(fit=True)

img = qr.make_image(fill = "black" , back_color = "white")
img.save("myqr.png")

img = Image.open("myqr.png")
img.show()

print("QR code is saved as myqr.png")